import React from 'react'
import { FaPlay } from 'react-icons/fa'
import posts from '../data/instagramPosts'

function GalleryGrid() {
  return (
    <div className="bg-pink-500 py-8 px-4">
        <div className="grid-cols-3 sm:grid-cols-3 gap-2 max-2-[640px] mx-auto"> 
            {posts.map((post) => (
                <a
                    key={post.id}
                    href={post.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="realtive group aspect-square overflow-hidden"
                >
                    <img
                        src={post.thumbnail}
                        alt="Instagram prev"
                        className="w-full h-full object-cover transition-transform duration-300 group:hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justtify-center opacity-0 group-hover:opacity-100 transition-opacity">
                        <FaPlay className="text-white text-3xl"/>
                    </div>
                </a>
            ))}
        </div>
    </div>
  )
}

export default GalleryGrid