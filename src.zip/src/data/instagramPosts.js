const posts = [
    {
        id: 1, 
        url: 'https://www.instagram.com/braidedbymyaa_/reel/DMViWYAu-1-/' ,
        thumbnail: 'https://media.igram.world/get?__sig=345-fs2RM4VsdszbZTGRwA&__expires=1753664445&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F522714206_18159316591372054_515069725568049010_n.jpg%3Fstp%3Ddst-jpg_e15_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D110%26_nc_oc%3DQ6cZ2QFC9zoydDOodERmfScxzRIoYklOk2rrxYXiikGC_hpUWMJGLND6g-FjmOxfJa-pKQghIKmgCfqegvENGcnG7SoU%26_nc_ohc%3DYznJhIEuLLIQ7kNvwH4dtkg%26_nc_gid%3DTYCkoafpG-HqNa2gnSdwxQ%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfTNOLoaoD8jMs7DFvY2hGyG8M99SfnQupLsIq7VC2fdYQ%26oe%3D688C9213%26_nc_sid%3Dd885a2&filename=522714206_18159316591372054_515069725568049010_n.jpg'
    },
    {
        id: 2,
        url: 'https://www.instagram.com/la_luxuriousbeauty_/p/DLKZiBwR4L6/?img_index=1',
        thumbnail: ' https://media.igram.world/get?__sig=AWg5irDHY-2-QJRoTgkfOA&__expires=1753664705&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F509946249_18014700926737396_1004993711884838231_n.jpg%3Fstp%3Ddst-jpg_e35_p1080x1080_sh0.08_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D104%26_nc_oc%3DQ6cZ2QEyq1WWZTPPVtJP5dfaAYaGXPWrqWmlUFBFhA5KSA-MyIH-_04WwUHYkG2bnkivNyps-14fszZYmaQW-8rVx0Ka%26_nc_ohc%3DaIBla1e9mjAQ7kNvwHM_a84%26_nc_gid%3DIE7w1WnBH0iEzGUyAemS1w%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfRqDTvoP11h0wrSfyi_rJ9-8exrH1y2OwCOp8UhxKDDKg%26oe%3D688CB1B3%26_nc_sid%3Dd885a2&filename=509946249_18014700926737396_1004993711884838231_n.jpg'
    },
    {
        id: 3,
        url: 'https://www.instagram.com/braidedbymyaa_/reel/DLx_tjzyYKa/',
        thumbnail: 'https://media.igram.world/get?__sig=MRKTqfBBdCpT0zWodE6FNA&__expires=1753667287&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F517094810_18158022037372054_4986650070110740107_n.jpg%3Fstp%3Ddst-jpg_e15_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D110%26_nc_oc%3DQ6cZ2QEO9P0tGuJnuLHUdwCUQ3Bm-lYH8lCLEHufX26daXSxC47o1g8guGjrUYw0MJhjrSaroCSv_qZXKxN-LW2Jn0gt%26_nc_ohc%3DPuaB9PIwzA0Q7kNvwH1b7ov%26_nc_gid%3DylBAzMPYocFyS9ge-ry1eA%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfRiTU8XK835f6jzPQl_FhSY2PvJ3p3HCqapPaHfndQSsA%26oe%3D688CBAB8%26_nc_sid%3Dd885a2&filename=517094810_18158022037372054_4986650070110740107_n.jpg'
    },
    {
        id: 4,
        url: 'https://www.instagram.com/la_luxuriousbeauty_/reel/DLIGhc9RHl8/',
        thumbnail: 'https://media.igram.world/get?__sig=ZosF3zqS6oq1Hy3STqlNmQ&__expires=1753667472&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F503707681_18014609033737396_4448016220246068543_n.jpg%3Fstp%3Ddst-jpg_e35_p1080x1080_sh0.08_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D104%26_nc_oc%3DQ6cZ2QFEul1cGjvSvoA8qKUgJ5lo5ezAt1YVbLvJ_cASsyzqzl4UVg6vethRONxYXXr3R33VnfKbJ6lTCM4MFC58Eqa1%26_nc_ohc%3DFCA_rS6TIzcQ7kNvwHaNANZ%26_nc_gid%3DxSiS69ilV1bvIJxuDgrLzw%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfQf6f13SQQggBJcoUcFj3hccur5tcsOFsWY2OwZ5RsFsg%26oe%3D688CAA18%26_nc_sid%3Dd885a2&filename=503707681_18014609033737396_4448016220246068543_n.jpg'
    },
    {
        id: 5,
        url: 'https://www.instagram.com/_luxesbeauty/p/DHTiG1KxfGK/?img_index=1',
        thumbnail: 'https://media.igram.world/get?__sig=Bzm5q6AVGZoh0HblmnX3TA&__expires=1753668320&uri=https%3A%2F%2Fscontent-lga3-1.cdninstagram.com%2Fv%2Ft51.2885-15%2F485585567_18036081572564675_2421196320329419585_n.jpg%3Fstp%3Ddst-jpg_e35_p1080x1080_sh0.08_tt6%26_nc_ht%3Dscontent-lga3-1.cdninstagram.com%26_nc_cat%3D111%26_nc_oc%3DQ6cZ2QFeKrWpJclI3BOVQ1cMOzoWNIcYBfxsoq1N2fvGfPyja3bDvfwD1rwS_kLQm1DfwPXK7U0xfWqBO8m8VhS4p8Vy%26_nc_ohc%3DsWNIBHv3SosQ7kNvwH5E7bQ%26_nc_gid%3DoDYLdG6dYTX1du0GDeDWOw%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfQQci2yDWPWEClHB87_wAQSI2jUvT3c_ADYP4KZH93C6g%26oe%3D688CB564%26_nc_sid%3Dd885a2&filename=485585567_18036081572564675_2421196320329419585_n.jpg'
    },
    {
        id: 6,
        url: 'https://www.instagram.com/la_luxuriousbeauty_/reel/DHboubNxRQ3/',
        thumbnail: 'https://media.igram.world/get?__sig=1-CQDTP4TNplJOuovQYz5g&__expires=1753668579&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F485301154_18004300028737396_4999939033045106808_n.jpg%3Fstp%3Ddst-jpg_e15_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D104%26_nc_oc%3DQ6cZ2QFkopAyBpqAhG7lws54yQvxZZ8M7GzRn_hdQMgdfTxHygQWjQfFPDM4uhC6RT0O3KI63NAJBJLs84McxGNygV-v%26_nc_ohc%3D7tR3s37hoAEQ7kNvwFT496x%26_nc_gid%3DvqMUZCaYzMVegMl-p2TvfA%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfRLTjf4QaBuK42awtDk5XEXOacM6BhiHEiKOjFeqIy69g%26oe%3D688CBE9D%26_nc_sid%3Dd885a2&filename=485301154_18004300028737396_4999939033045106808_n.jpg'
    },
    {
        id: 7,
        url: 'https://www.instagram.com/iecrichmond/reel/DChbwD7Rn6B/',
        thumbnail: 'https://media.igram.world/get?__sig=AzpB_kE7nSsM0gpYmpPLuQ&__expires=1753668991&uri=https%3A%2F%2Fscontent-lga3-2.cdninstagram.com%2Fv%2Ft51.2885-15%2F467410256_18466505128003339_5943027852766829125_n.jpg%3Fstp%3Ddst-jpg_e15_tt6%26_nc_ht%3Dscontent-lga3-2.cdninstagram.com%26_nc_cat%3D107%26_nc_oc%3DQ6cZ2QHfhUyZKW8Bz9Pn3R36zP3PcSSNn0qn7nT4QqpWS2lUBzV84MpMOEhArSF_vLabnNNGenn98lfkYhUJVE5xzP9Z%26_nc_ohc%3Dm7Epfv2rFiQQ7kNvwGPNnJ2%26_nc_gid%3DXKnMi153qzMzr1bzgzA6iA%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfRlrhVn45CB3pknMPcE0wGnjPxEi6TV9-qfLR0XiuniLA%26oe%3D688C98CB%26_nc_sid%3Dd885a2&filename=467410256_18466505128003339_5943027852766829125_n.jpg'
    },
    {
        id: 8,
        url: 'https://www.instagram.com/datnailgal_804/reel/DJS98RdxC7u/',
        thumbnail:'https://media.igram.world/get?__sig=-kcoPqeLNf2_eEkEsFJf2w&__expires=1753669265&uri=https%3A%2F%2Fscontent-lga3-2.cdninstagram.com%2Fv%2Ft51.2885-15%2F496014743_1403116740827285_1022723764573250622_n.jpg%3Fstp%3Ddst-jpg_e15_tt6%26_nc_ht%3Dscontent-lga3-2.cdninstagram.com%26_nc_cat%3D105%26_nc_oc%3DQ6cZ2QHFzFK5Xs1WBE3nlHBHFLLs_Zm9TY4TkT1b6LH9rbZ33KHaZfPt8JlxoHOJ0tYVPaTmYWpTf17YPeJwOsj83od_%26_nc_ohc%3Dy7_tLfo0_fIQ7kNvwF9kXAW%26_nc_gid%3Dnuz_Y_hiV3KUWlpcopTrww%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfTV-q2zLbb_PHDacvQnsYjYuA1tkUCeqjRQWM9z1SHRTw%26oe%3D688C9AA9%26_nc_sid%3Dd885a2&filename=496014743_1403116740827285_1022723764573250622_n.jpg'
    },
    {
        id: 9,
        url: 'https://www.instagram.com/iamshaybland/reel/DAw5dxbRaB5/',
        thumbnail: 'https://media.igram.world/get?__sig=hiOSaMMo_Ojt4l38dzXMFA&__expires=1753670349&uri=https%3A%2F%2Fscontent-lga3-3.cdninstagram.com%2Fv%2Ft51.2885-15%2F503218986_721914266892280_1313329111151623131_n.jpg%3Fstp%3Ddst-jpg_e35_p1080x1080_sh0.08_tt6%26_nc_ht%3Dscontent-lga3-3.cdninstagram.com%26_nc_cat%3D104%26_nc_oc%3DQ6cZ2QFW7n7LLFlcr1RjRMfUmhMvZYQ6yZgoUbCMzq7nuMEyE5zjUqEQu62xpmOPwh0PGAN3NsrnxPw3bSSSmkzgwXoP%26_nc_ohc%3Df7BLGEFbnAQQ7kNvwENGNhr%26_nc_gid%3DBBirVwpXdL1Pv8apUlqxTA%26edm%3DANTKIIoBAAAA%26ccb%3D7-5%26oh%3D00_AfQJzDcGz5zjy5-CZ3XtTFnQr8QTqFR5lHaVegszDh0yqA%26oe%3D688CB130%26_nc_sid%3Dd885a2&filename=503218986_721914266892280_1313329111151623131_n.jpg'
    },
]

export default posts;