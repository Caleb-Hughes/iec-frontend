const teamMembers =[
    {name: 'Dionne Hughes', role: 'Salon Owner', img: '/TeamPics/dionne.png'},
    {name: 'Liz Anderson', role: 'Hair Stylist', img: '/TeamPics/liz.png'},
    {name: 'Whitley Hughes', role: 'Nail Technician', img: '/TeamPics/whitley.png'},
    {name: 'Alex Moore', role: 'Hair Stylist', img: '/TeamPics/alex.png'},
    {name: 'Ashley Lace', role: 'Hair Stylist', img: '/TeamPics/ashley.png'}
];

export default teamMembers;